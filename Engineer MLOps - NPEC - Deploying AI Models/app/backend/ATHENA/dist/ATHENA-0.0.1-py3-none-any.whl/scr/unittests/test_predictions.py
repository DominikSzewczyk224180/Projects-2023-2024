import unittest
from unittest.mock import MagicMock, patch
import numpy as np
import json
import os
import sys

root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(root)

from predictions import get_num_classes, custom_argmax, unpatchify

class TestModelUtilities(unittest.TestCase):
    """
    Unit tests for the utility functions used in image segmentation model operations.

    Author: Benjamin Graziadei
    """

    def test_get_num_classes(self):
        """
        Test the `get_num_classes` function to ensure it correctly extracts the number of classes from a model's configuration.

        Author: Benjamin Graziadei
        """
        file_path = os.path.join(root, 'unittests', 'model_test.json')
        
        # Load the JSON configuration from the file
        with open(file_path, 'r') as file:
            config_json = file.read()
            config_dict = json.loads(config_json)
        

        # Call the function with the simulated configuration
        num_classes = get_num_classes(config_dict)

        # Assert to check if the correct number of classes is returned
        self.assertEqual(num_classes, 4, "The number of classes extracted should be 10")


    def test_custom_argmax(self):
        """
        Test the `custom_argmax` function to verify it correctly applies a bias and computes the argmax.

        Author: Benjamin Graziadei
        """
        probabilities = np.array([[[0.2, 0.3, 0.5],
                                   [0.6, 0.2, 0.2]],
                                  [[0.1, 0.8, 0.1],
                                   [0.5, 0.2, 0.3]]])
        bias = 0.1
        expected_output = np.array([[2, 0],
                                    [1, 0]])
        output = custom_argmax(probabilities, bias)
        np.testing.assert_array_equal(output, expected_output)

    def test_unpatchify(self):
        """
        Test the `unpatchify` function to ensure it correctly reconstructs an image from patches considering the overlapping.

        Author: Benjamin Graziadei
        """
        # Define the patch size and calculate step size based on overlap
        patch_size = 100
        step_size = int(patch_size/8) *7
        patches_per_dim = 2  # Example for a 2x2 grid of patches

        # Calculate the expected final dimensions
        expected_height = expected_width = (patches_per_dim - 1) * step_size + patch_size

        # Create an array simulating 4 overlapping patches
        patches = np.random.rand(patches_per_dim**2, patch_size, patch_size, 3)  # 4 patches

        reconstructed_image = unpatchify(patches, patch_size)
        self.assertEqual(reconstructed_image.shape, (expected_height, expected_width, 3))


if __name__ == '__main__':
    unittest.main()
