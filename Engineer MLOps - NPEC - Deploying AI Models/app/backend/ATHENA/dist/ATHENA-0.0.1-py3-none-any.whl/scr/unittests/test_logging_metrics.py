import os
import sys
import unittest
import tensorflow as tf
from unittest.mock import patch, MagicMock

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from logging_metrics import (TrainingLogger)

class TestTrainingLogger(unittest.TestCase):

    @patch('model_training_2.logging.info')
    def test_on_train_begin(self, mock_logging_info):
        callback = TrainingLogger()
        callback.on_train_begin()

        self.assertEqual(callback.epoch_count, 0)
        mock_logging_info.assert_called_once_with('Training started.')

    @patch('model_training_2.logging.info')
    def test_on_epoch_end(self, mock_logging_info):
        callback = TrainingLogger()
        callback.log_epoch_end = MagicMock()

        logs = {
            'loss': 0.1,
            'accuracy': 0.9,
            'val_loss': 0.2,
            'val_accuracy': 0.85,
            'f1': 0.88,
            'val_f1': 0.84,
            'iou': 0.75,
            'val_iou': 0.7
        }

        callback.on_epoch_end(epoch=0, logs=logs)

        self.assertEqual(callback.epoch_count, 1)
        callback.log_epoch_end.assert_called_once_with(0, logs)

    @patch('models.model_training_2.logging.info')
    def test_on_train_end(self, mock_logging_info):
        callback = TrainingLogger()
        callback.epoch_count = 5
        callback.on_train_end()

        mock_logging_info.assert_called_once_with('Training finished after 5 epochs.')

    @patch('models.model_training_2.logging.info')
    def test_log_epoch_end(self, mock_logging_info):
        callback = TrainingLogger()

        logs = {
            'loss': 0.1,
            'accuracy': 0.9,
            'val_loss': 0.2,
            'val_accuracy': 0.85,
            'f1': 0.88,
            'val_f1': 0.84,
            'iou': 0.75,
            'val_iou': 0.7
        }

        callback.log_epoch_end(epoch=0, logs=logs)

        mock_logging_info.assert_called_once_with(
            'Epoch 1 - Loss: 0.1000, Accuracy: 0.9000, F1: 0.8800, IoU: 0.7500, '
            'Val_loss: 0.2000, Val_accuracy: 0.8500, Val_f1: 0.8400, Val_IoU: 0.7000'
        )

if __name__ == '__main__':
    unittest.main()
