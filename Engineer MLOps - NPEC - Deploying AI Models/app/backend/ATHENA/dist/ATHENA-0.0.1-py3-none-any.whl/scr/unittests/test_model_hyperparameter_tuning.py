import os
import sys
import unittest
import tensorflow as tf
import numpy as np
import keras_tuner as kt
from unittest.mock import patch, MagicMock

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from model_hyperparameter_tuning import compile_model, train_and_evaluate, MyTuner


path = '../data/processed/NPEC'


class Test_compiler_training(unittest.TestCase):

    def test_compile_model(self):
        # Create a mock U-Net model
        mock_model = MagicMock()

        # Create a mock metrics list
        mock_metrics = ['accuracy']

        # Call the function with 'adam' optimizer
        learning_rate = 0.001
        compiled_model = compile_model(mock_model, 'adam', learning_rate, mock_metrics)

        # Assertions
        mock_model.compile.assert_called_once()
        args, kwargs = mock_model.compile.call_args
        self.assertIsInstance(kwargs['optimizer'], tf.keras.optimizers.Optimizer)
        self.assertAlmostEqual(kwargs['optimizer'].learning_rate.numpy(), learning_rate, delta=1e-7)
        self.assertEqual(kwargs['loss'], 'binary_crossentropy')
        self.assertEqual(kwargs['metrics'], mock_metrics)

    @patch('model_hyperparameter_tuning.compile_model')
    def test_train_and_evaluate(self, mock_compile_model):
        # Create a mock model
        mock_model = MagicMock(spec=tf.keras.Model)
        mock_compile_model.return_value = mock_model

        # Mock the fit and evaluate methods
        mock_model.fit = MagicMock()
        mock_model.evaluate = MagicMock(return_value=[0.5, 0.8])

        # Create mock train and validation data
        mock_train_data = MagicMock()
        mock_val_data = MagicMock()

        # Mock the steps per epoch and validation steps
        steps_train = 16900 / 32
        steps_valid = 2197 / 32

        # Define the number of epochs and early stopping
        epochs = 5

        # Call the function with mocked parameters
        trained_model, _, evaluation = train_and_evaluate(mock_model, mock_train_data, mock_val_data, epochs)

        # Assertions
        self.assertIsInstance(trained_model, tf.keras.Model)
        self.assertEqual(evaluation, [0.5, 0.8])  # Check the mocked evaluation result

        # Verify that the model's fit and evaluate methods were called
        mock_model.fit.assert_called_with(
            mock_train_data,
            epochs=epochs,
            steps_per_epoch=steps_train,
            validation_data=mock_val_data,
            validation_steps=steps_valid,
            callbacks=None
        )
        mock_model.evaluate.assert_called_with(mock_val_data, steps=steps_valid)

class TestMyTuner(unittest.TestCase):
    def setUp(self):
        # Set up mock objects or any necessary test data
        self.model = MagicMock()
        self.train_data = MagicMock()
        self.valid_data = MagicMock()
        self.epochs = 10
        self.early_stopping = MagicMock()

    def test_initialization(self):
        tuner = MyTuner(self.model, self.train_data, self.valid_data, self.epochs, self.early_stopping)
        self.assertEqual(tuner.model, self.model)
        self.assertEqual(tuner.train_data, self.train_data)
        self.assertEqual(tuner.valid_data, self.valid_data)
        self.assertEqual(tuner.epochs, self.epochs)
        self.assertEqual(tuner.early_stopping, self.early_stopping)

    @patch("model_hyperparameter_tuning.train_and_evaluate")
    def test_run_trial(self, mock_train_and_evaluate):
        tuner = MyTuner(self.model, self.train_data, self.valid_data, self.epochs, self.early_stopping)
        trial = MagicMock()
        trial.hyperparameters = MagicMock()
        trial.hyperparameters.Choice.side_effect = [64, 'adam']
        trial.hyperparameters.Float.return_value = 0.001

        mock_train_and_evaluate.return_value = (self.model, None, (0.8, 0.9))

        evaluation = tuner.run_trial(trial)

        # Assuming evaluation[1] represents validation accuracy
        self.assertEqual(evaluation, 0.9)
        mock_train_and_evaluate.assert_called_once_with(
            self.model,
            self.train_data,
            self.valid_data,
            self.epochs,
            early_stopping=self.early_stopping,
            batch_size=64,  # The value returned by trial.hyperparameters.Choice
            learning_rate=0.001,  # The value returned by trial.hyperparameters.Float
            optimizer='adam',
            metrics=['accuracy']  # The value returned by trial.hyperparameters.Choice
        )

if __name__ == '__main__':
    unittest.main()
