import os
import sys
import unittest
from unittest.mock import patch, MagicMock
import numpy as np
from keras.preprocessing.image import ImageDataGenerator

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from image_data_generator import train_generator, test_generator, val_generator, get_available_mask_subfolders

# Create the test class
class TestScript(unittest.TestCase):
    @patch('os.scandir')
    def test_get_available_mask_subfolders(self, mock_scandir):
        # Mock the os.scandir to simulate file system
        mock_scandir.return_value = ['subfolder1', 'subfolder2']
        
        result = get_available_mask_subfolders('fake_mask_folder')
        self.assertEqual(result, ['subfolder1', 'subfolder2'])
        
        # Test FileNotFoundError
        mock_scandir.side_effect = FileNotFoundError
        result = get_available_mask_subfolders('fake_mask_folder')
        self.assertEqual(result, [])

    @patch('image_data_generator.ImageDataGenerator')
    @patch('image_data_generator.get_available_mask_subfolders')
    @patch('image_data_generator.os.path.join')
    def test_train_generator(self, mock_join, mock_get_subfolders, mock_ImageDataGenerator):
        # Mock the return values
        mock_get_subfolders.return_value = ['root1', 'root2', 'subfolder1']
        mock_join.side_effect = lambda *args: '/'.join(args)
        
        # Create mock generators
        mock_image_gen = MagicMock()
        mock_image_gen.flow_from_directory.return_value.next.return_value = np.zeros((2, 256, 256, 1))
        mock_mask_gen = MagicMock()
        mock_mask_gen.flow_from_directory.return_value.next.return_value = np.zeros((2, 256, 256, 1))
        
        mock_ImageDataGenerator.return_value = mock_image_gen
        mock_ImageDataGenerator.return_value = mock_mask_gen

        gen = train_generator({}, 2)
        img, mask = next(gen)
        self.assertEqual(img.shape, (2, 256, 256, 1))
        self.assertEqual(mask.shape, (2, 256, 256, 3))

    @patch('image_data_generator.ImageDataGenerator')
    @patch('image_data_generator.get_available_mask_subfolders')
    @patch('image_data_generator.os.path.join')
    def test_test_generator(self, mock_join, mock_get_subfolders, mock_ImageDataGenerator):
        # Mock the return values
        mock_get_subfolders.return_value = ['root1', 'root2', 'subfolder1']
        mock_join.side_effect = lambda *args: '/'.join(args)
        
        # Create mock generators
        mock_image_gen = MagicMock()
        mock_image_gen.flow_from_directory.return_value.next.return_value = np.zeros((2, 256, 256, 1))
        mock_image_gen.flow_from_directory.return_value.filenames = ['test_image_1.png', 'test_image_2.png']
        mock_image_gen.flow_from_directory.return_value.samples = 4  # Setting samples directly
        mock_mask_gen = MagicMock()
        mock_mask_gen.flow_from_directory.return_value.next.return_value = np.zeros((2, 256, 256, 1))
        
        mock_ImageDataGenerator.return_value.flow_from_directory.return_value.samples = 4
        mock_ImageDataGenerator.return_value.flow_from_directory.return_value = mock_image_gen.flow_from_directory.return_value
        mock_ImageDataGenerator.return_value = mock_image_gen

        gen = test_generator(2)
        img, mask, img_filenames = next(gen)
        self.assertEqual(img.shape, (2, 256, 256, 1))
        self.assertEqual(mask.shape, (2, 256, 256, 3))
        self.assertEqual(img_filenames, 'test_image_1')

    @patch('image_data_generator.ImageDataGenerator')
    @patch('image_data_generator.get_available_mask_subfolders')
    @patch('image_data_generator.os.path.join')
    def test_val_generator(self, mock_join, mock_get_subfolders, mock_ImageDataGenerator):
        # Mock the return values
        mock_get_subfolders.return_value = ['root1', 'root2', 'subfolder1']
        mock_join.side_effect = lambda *args: '/'.join(args)
        
        # Create mock generators
        mock_image_gen = MagicMock()
        mock_image_gen.flow_from_directory.return_value.next.return_value = np.zeros((2, 256, 256, 1))
        mock_mask_gen = MagicMock()
        mock_mask_gen.flow_from_directory.return_value.next.return_value = np.zeros((2, 256, 256, 1))
        
        mock_ImageDataGenerator.return_value = mock_image_gen
        mock_ImageDataGenerator.return_value = mock_mask_gen

        gen = val_generator(2)
        img, mask = next(gen)
        self.assertEqual(img.shape, (2, 256, 256, 1))
        self.assertEqual(mask.shape, (2, 256, 256, 3))

if __name__ == '__main__':
    unittest.main()
